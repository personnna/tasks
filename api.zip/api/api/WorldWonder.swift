//
//  WorldWonder.swift
//  api
//
//  Created by eldana on 26.08.2023.
//

import Foundation
import SwiftyJSON

struct WorldWonder{
    var name = ""
    var location = ""
    var picture = ""
    var flag = ""
    
    init(json: JSON) {
        if let item = json["name"].string{
            name = item
        }
        if let item = json["location"].string{
            location = item
        }
        if let item = json["picture"].string{
            picture = item
        }
        if let item = json["flag"].string{
            flag = item
        }
    }
}


