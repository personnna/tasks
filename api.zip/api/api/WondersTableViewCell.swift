//
//  WondersTableViewCell.swift
//  api
//
//  Created by eldana on 26.08.2023.
//

import UIKit
import SDWebImage

class WondersTableViewCell: UITableViewCell {

    @IBOutlet weak var pictureImageView: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var flagImageView: UIImageView!
    
    @IBOutlet weak var locationLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setData(wonder: WorldWonder){
        nameLabel.text = wonder.name
        locationLabel.text = wonder.location
        pictureImageView.sd_setImage(with: URL(string: wonder.picture), completed: nil)
        flagImageView.sd_setImage(with: URL(string: wonder.flag), completed: nil)
    }

}
