/*:
## Exercise - For-In Loops
 
 Create a for-in loop that loops through values 1 to 100, and prints each of the values.
 */
/*:
Создайте цикл for-in, который перебирает значения от 1 до 100 и печатает каждое из значений.
 */


/*:
page 1 of 6  |  [Next: App Exercise - Finding Movements](@next)
 */
