//
//  Place.swift
//  mapview
//
//  Created by eldana on 24.08.2023.
//

import Foundation
import MapKit

struct Place{
    var image = ""
    var name = ""
    var decription = ""
    var latitude: Double = 0.0
    var longitude: Double = 0.0
    
}
