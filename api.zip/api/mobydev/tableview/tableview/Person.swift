//
//  Person.swift
//  tableview
//
//  Created by eldana on 15.07.2023.
//

import Foundation

struct Person{
    var name = ""
    var surname = ""
    var imagename = ""
}
