//
//  TaskItem.swift
//  todolistt
//
//  Created by eldana on 17.07.2023.
//

import Foundation

struct TaskItem: Codable {
    var name = ""
    var isComplete = false
}
