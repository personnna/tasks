//
//  Music.swift
//  musictableview
//
//  Created by eldana on 16.07.2023.
//

import Foundation
struct Music{
    var name = ""
    var singer = ""
    var image = ""
}
